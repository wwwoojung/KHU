<main id="content">
            <div id="sub_page">
                <div class="title_box" style="background: url(../images/sub_page_bg0<?=$cate_num;?>.jpeg) no-repeat center center/cover;">
                    <h2><?=$cate_tit;?></h2>
                    <div class="text_box">
                        <div class="inner">
                            <strong><?=$cate_tit;?></strong> / <span><?=$page_tit;?></span>
                        </div>
                    </div>
                </div>
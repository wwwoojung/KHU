<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}

include_once(G5_THEME_PATH.'/head.php');
?>

<main id="content" class="main">
            <section class="MainVisual">
                <h2 class="blind">main visual slide</h2>
                <div class="swiper visual_slide">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide itm itm01">
                            <div class="text_box">
                                <strong>스마트팜과학과 재학생팀</strong>
                                <span>농업용 로봇 경진대회 최우수상 수상</span>
                                <p>
                                    스마트팜과학과 IT, 데이터분석, 공학 융합 커리큘럼 도움
                                </p>
                            </div>
                        </div>
                        <div class="swiper-slide itm itm02">
                            <div class="text_box">
                                <strong>응용수학과 학생</strong>
                                <span>SCIE 저널에 1저자로 참여</span>
                                <p>
                                    응용수학과 박준표 교수 연구팀, 순환경쟁구조 분석해 생존 전이 발생 원인 도식화
                                </p>
                            </div>
                        </div>
                        <div class="swiper-slide itm itm03">
                            <div class="text_box">
                                <strong>대학혁신지원사업으로</strong>
                                <span>글로벌 연구기관과 공동연구 나서</span>
                                <p>
                                    정보전자신소재공학과 학부 연구생,<br />
                                    교육혁신사업단 프로그램으로 미국 대학 연구실 탐방
                                </p>
                            </div>
                        </div>
                        <div class="swiper-slide itm itm04">
                            <div class="text_box">
                                <strong>교원 창업, 교육·연구·실천</strong>
                                <span>세 마리 토끼 모두 잡아야</span>
                                <p>
                                    의과대학 김도경 교수, 진단 및 치료 의료소재 기업 ‘엘레노바’ 창업
                                </p>
                            </div>
                        </div>
                        <div class="swiper-slide itm itm05">
                            <div class="text_box">
                                <span>물방울 기반 하이브리드 발전기 개발</span>
                                <p>
                                    기계공학과 최동휘 교수 연구팀,<br />
                                    물방울 기반 전기 발전기와 마찰전기 발전기 융합
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="slide_dots">
                        <div class="swiper-pagination"></div>
                        <button class="pause">
                            pause
                        </button>
                    </div>
                    <div class="slide_arrows">
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    </div>
                </div>
            </section>
            <section class="MainFocus default">
                <div class="title">
                    <h2>Focus</h2>
                </div>
                <div class="inner focus_con">
                    <div class="content">
                        <div class="img_box">
                            <img src="<?=G5_THEME_URL;?>/images/main_focus01.jpg" alt="focus content">
                        </div>
                        <div class="text_box">
                            <strong>“교육·학술기관 본연의 책무 다하면서 자긍심 회복해야”</strong>
                            <p>
                                조인원 경희학원 이사장은 대학 신임 교무위원 임명장 수여 후, “보직을 수행한다는 것은 한 기관의 역사에 대한 책무, 현실에 대한 책무, 미래에 대한 책무를
                                양어깨에 짊어지는 일이다. 보직자 한 분 한 분이 설립의 주체이자 대학의 현장 경영을 이끌어가는 책임자라는 마음으로 보직에 임해야 한다. 그것이 시대의
                                요청이기도 하고, 우리가 원하는 탁월성의 미래를 열어갈 힘이기도 하다”라고 말했다.
                            </p>
                            <button class="more_btn">more</button>
                        </div>
                    </div>
                    <div class="content">
                        <div class="img_box">
                            <img src="<?=G5_THEME_URL;?>/images/main_focus02.jpg" alt="focus content">
                        </div>
                        <div class="text_box">
                            <strong>“학과 장벽 넘는 융합, 사회적 요구이자 피할 수 없는 현실”</strong>
                            <p>
                                2023학년도 제8차 교무위원회가 개최됐다. 이번 교무위원회의 주요 안건은 모집 단위 광역화 개요와 2023년 경희의 성취였다.
                            </p>
                            <button class="more_btn">more</button>
                        </div>
                    </div>
                    <div class="content">
                        <div class="img_box">
                            <img src="<?=G5_THEME_URL;?>/images/main_focus03.jpg" alt="focus content">
                        </div>
                        <div class="text_box">
                            <strong>국제학과 학생, 유엔 국제행사에서 한국 대표로 발표</strong>
                            <p>
                                국제학과 학생으로 구성된 팀이 ‘2023 유엔 지속가능발전목표 정상회의’ 후속 행사인 ‘Greening Global Citizenship
                                Education’에서 한국 대표로 발표했다.
                            </p>
                            <button class="more_btn">more</button>
                        </div>
                    </div>
                </div>
            </section>
            <section class="MainLink default">
                <div class="inner link_con">
                    <div class="link_title">
                        <h2>Link</h2>
                        <p>경희대학교의 다양한 정보를 빠르게 만나보세요</p>
                    </div>
                    <div class="link_container">
                        <ul>
                            <li><a href="">2024-1(2차) 외국인 신편입학 합격자발표(공통)</a></li>
                            <li><a href="">2024-1(1차) 외국인 신편입학 등록금 납부(공통)</a></li>
                            <li><a href="">경희대학교 복지몰</a></li>
                            <li><a href="">ChatGPT 활용 가이드라인</a></li>
                            <li><a href="">2024-1 학부 외국인 신편입학전형 모집요강</a></li>
                            <li><a href="">2024-1 일반대학원 외국인 신입학 전형 모집요강</a></li>
                            <li><a href="">대학안전관리</a></li>
                            <li><a href="">후마니타스칼리지 가이드북</a></li>
                            <li><a href="">대학원혁신지원사업단</a></li>
                            <li><a href="">취업진로정보</a></li>
                            <li><a href="">교내장학 신청</a></li>
                            <li><a href="">학자금대출/국가장학금 신청</a></li>
                            <li><a href="">대학혁신지원사업</a></li>
                            <li><a href="">경희옴부즈/통합민원</a></li>
                            <li><a href="">국가 R&D사업 공고</a></li>
                            <li><a href="">LINC3.0 사업단</a></li>
                            <li><a href="">발전기금(GIVE경희)</a></li>
                            <li><a href="">글쓰기센터</a></li>
                            <li><a href="">KHU SDGs / KHU ESG</a></li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="MainNotice default">
                <h2 class="blind">Main Announcement and News</h2>
                <div class="inner notice_con">
                    <div class="annoucement_con">
                        <div class="top_content">
                            <h3>Announcement</h3>
                            <ul class="tab_menu">
                                <li class="on"><a href="">일반</a></li>
                                <li><a href="">장학</a></li>
                                <li><a href="">학사</a></li>
                                <li><a href="">행사</a></li>
                            </ul>
                        </div>
                        <div class="tab_con">
                            <div class="content on">
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용공고</strong>
                                        <span>2024.01.09</span>
                                    </div>
                                    <p>
                                        경희대학교 미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용 공고
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용공고</strong>
                                        <span>2024.01.09</span>
                                    </div>
                                    <p>
                                        경희대학교 미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용 공고
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용공고</strong>
                                        <span>2024.01.09</span>
                                    </div>
                                    <p>
                                        경희대학교 미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용 공고
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용공고</strong>
                                        <span>2024.01.09</span>
                                    </div>
                                    <p>
                                        경희대학교 미래문명원 글로벌사업팀 기간제 근로자(육아휴직 대체) 채용 공고
                                    </p>
                                </div>
                            </div>
                            <div class="content">
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>[KT&G] 상상유니브 상상프렌즈 17기 모집</strong>
                                        <span>2024-01-09</span>
                                    </div>
                                    <p>
                                        15년차 대학생 대표 갓생 프로젝트 상상프렌즈 17기 모집을 시작합니다!
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>[KT&G] 상상유니브 상상프렌즈 17기 모집</strong>
                                        <span>2024-01-09</span>
                                    </div>
                                    <p>
                                        15년차 대학생 대표 갓생 프로젝트 상상프렌즈 17기 모집을 시작합니다!
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>[KT&G] 상상유니브 상상프렌즈 17기 모집</strong>
                                        <span>2024-01-09</span>
                                    </div>
                                    <p>
                                        15년차 대학생 대표 갓생 프로젝트 상상프렌즈 17기 모집을 시작합니다!
                                    </p>
                                </div>
                                <div class="con_box">
                                    <div class="tit">
                                        <strong>[KT&G] 상상유니브 상상프렌즈 17기 모집</strong>
                                        <span>2024-01-09</span>
                                    </div>
                                    <p>
                                        15년차 대학생 대표 갓생 프로젝트 상상프렌즈 17기 모집을 시작합니다!
                                    </p>
                                </div>
                            </div>
                            <div class="content"></div>
                            <div class="content"></div>
                        </div>
                    </div>
                    <div class="news_con">
                        <div class="top_content">
                            <h3>News</h3>
                            <a href="">
                                <span class="material-symbols-outlined">
                                    add
                                </span>
                            </a>
                        </div>
                        <div class="news_box">
                            <div class="news">
                                <img src="<?=G5_THEME_URL;?>/images/main_news01.jpeg" alt="">
                            </div>
                            <div class="news">
                                <img src="<?=G5_THEME_URL;?>/images/main_news02.jpeg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="MainFame">
                <h2 class="blind">명예의 전당</h2>
                <div class="inner">
                    <strong>Hall of Fame</strong>
                    <div class="img_box">
                        <img src="<?=G5_THEME_URL;?>/images/main_fame.png" alt="fame image">
                    </div>
                    <p>
                        교육과 연구의 탁월성을 통해 경희대학교를 빛낸 “Honorable Professor”
                    </p>
                    <button class="more_btn">명예의전당 바로가기</button>
                </div>
            </section>
        </main>

<?php
include_once(G5_THEME_PATH.'/tail.php');
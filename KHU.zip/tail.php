<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/tail.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/shop.tail.php');
    return;
}
?>

<?php
    if(!defined('_INDEX_')) {
        include G5_THEME_PATH.'/sub.tail.php'; // 팝업레이어
    }
    ?>

<footer id="Footer" class="Footer">
            <div class="footer_top">
                <ul class="footer_menu">
                    <li><a href="">교내전화번호</a></li>
                    <li><a href="" style="font-weight: 600;">개인정보처리방침</a></li>
                    <li><a href="">대학정보공시</a></li>
                    <li><a href="">예결산공고</a></li>
                    <li><a href="">입찰공고</a></li>
                </ul>
                <div class="family_site">
                    <select name="KHU_inner_site" id="KHU_inner_site">
                        <option value="">교내주요사이트</option>
                        <option value="">e-campus</option>
                        <option value="">교무처</option>
                        <option value="">경희옴부즈</option>
                        <option value="">교수학습지원센터</option>
                        <option value="">중앙도서관</option>
                        <option value="">중앙박물관</option>
                        <option value="">학군단(서울)</option>
                        <option value="">학군단(국제)</option>
                    </select>
                    <select name="KHU_outter_site" id="KHU_outter_site">
                        <option value="">경희대학교 관련기관</option>
                        <option value="">강동경희대학교병원</option>
                        <option value="">경희고등학교</option>
                        <option value="">경희사이버대학교</option>
                        <option value="">경희의료원</option>
                        <option value="">총동문회</option>
                    </select>
                    <select name="KHU_sns" id="KHU_sns">
                        <option value="">경희대학교 SNS</option>
                        <option value="">인스타그램</option>
                        <option value="">유튜브</option>
                        <option value="">페이스북</option>
                        <option value="">블로그</option>
                        <option value="">트위터</option>
                    </select>
                </div>
            </div>
            <div class="footer_bottom">
                <div class="footer_logo">
                    <img src="<?=G5_THEME_URL;?>/images/footLogo.png" alt="">
                </div>
                <address class="copyright">
                    <ul>
                        <li>서울캠퍼스 02447 서울특별시 동대문구 경희대로 26</li>
                        <li>국제캠퍼스 17104 경기도 용인시 기흥구 덕영대로 1732</li>
                        <li>광릉캠퍼스 12001 경기도 남양주시 진접읍 광릉수목원로 195</li>
                    </ul>
                    <p>COPYRIGHT &copy; KYUNG HEE UNIVERSITY. ALL RIGHT RESERVED.</p>
                </address>
            </div>
        </footer>
    </div>

<?php
if(G5_DEVICE_BUTTON_DISPLAY && !G5_IS_MOBILE) { ?>
<?php
}

if ($config['cf_analytics']) {
    echo $config['cf_analytics'];
}
?>

<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>

<?php
include_once(G5_THEME_PATH."/tail.sub.php");
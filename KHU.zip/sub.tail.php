</article>
                    <aside class="side_nav">
                        <?include G5_THEME_PATH.'/nav.php'?>
                        <figure>
                            <img src="<?=G5_THEME_URL;?>/images/sub_page_logo.png" alt="">
                        </figure>
                    </aside>
                </div>
            </div>

            <script>
            $(function(){
                let num = <?=$cate_num;?>;
                $('.side_nav>ul>li').eq(num - 1).addClass('on');
            })
        </script>
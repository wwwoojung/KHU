<ul>
                            <li><a href="<?=G5_THEME_URL;?>/doc/m011.php">대학</a></li>
                            <li><a href="<?=G5_THEME_URL;?>/doc/m021.php">입학</a></li>
                            <li><a href="<?=G5_THEME_URL;?>/doc/m031.php">교육</a></li>
                            <li><a href="<?=G5_THEME_URL;?>/doc/m041.php">연구/산학</a></li>
                            <li><a href="">교류/실천</a></li>
                            <li><a href="">대학생활</a></li>
                        </ul>
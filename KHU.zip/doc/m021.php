<?
$cate_num = 2;
$page_num = 1;
$cate_tit = '입학';
$page_tit = '경희대학교';
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>


                <div class="inner content_box">
                    <article class="content">
                        <h3>대학 입학/편입학</h3>
                        <figure>
                            <img src="<?=G5_THEME_URL;?>/images/imgSub02.jpg" alt="경희대학교">
                        </figure>
                        <p>
                        수시모집(재외국민특별전형, 학생부종합전형, 실기우수자전형, 논술우수자전형), 정시모집 (수능100, 실기포함) 등을 통해 성적 위주의 획일적 선발 방식에서 벗어나 미래사회가 요구하는 창의적이고 진취적인 인재를 발굴하고 있다.
                        </p>
                        <div class="more_btn">입학처</div>
                    </article>


                    <style>
                        #sub_page .content p{
                            margin: 0 0 3.2rem 0;
                        }
                        #sub_page .more_btn{
                            display: inline-block;
                        }
                    </style>


<?php
include_once(G5_THEME_PATH.'/tail.php');
?>